#!/bin/bash

sudo /sbin/shutdown -P now

